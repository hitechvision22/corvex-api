<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>

<body>
    <div>
        <div>
            <p>Salut Mr/Mme <?php echo e($user->name); ?>, votre publication de covoiturage concernant le voyage
                <strong>
                    <?php echo e($trajet->ville_depart . ' (' . $trajet->point_rencontre . ') '); ?>

                </strong>
                vers
                <strong>
                    <?php echo e($trajet->ville_destination . ' (' . $trajet->point_destination . ') '); ?>

                </strong>
                a été accepté
                <?php echo e($trajet->etat == 'Deactif' ? 'ce pendant, vous devez completer vos informations (cni, carte grise et permis) pour l\'activation' : ''); ?>

            </p>
        </div>
    </div>
</body>

</html>
<?php /**PATH C:\laragon\www\corvex-api\resources\views/mails/trajets/NewPostInfo.blade.php ENDPATH**/ ?>